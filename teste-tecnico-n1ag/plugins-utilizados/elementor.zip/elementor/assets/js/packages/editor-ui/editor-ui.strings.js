__( "Don't show this again", 'elementor' );
__( 'Got it', 'elementor' );
__( 'Clear', 'elementor' );